// **********************************************************************************
// Trentino - A C++ based lightweight, non-invasive SCA runtime.
// Copyright 2011 by Siemens AG. All rights reserved.
// http://trentino.sourceforge.net/
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// **********************************************************************************

#ifndef TrentinoSCAModelComponentH
#define TrentinoSCAModelComponentH
//baseclass
#include "TrentinoSCAModelCommonExtensionBase.h"
//standard
#include <vector>

//specific
#include "TrentinoSCAModel.h"

namespace Trentino{
namespace SCA{
namespace Model
{
   class SCAMODEL_IMPORT_EXPORT Component : public CommonExtensionBase
   {
      //construction
   public:
      Component();
      virtual ~Component() {}; 
   private:
      Component(const Component&);
      void operator=(const Component&);

      //services
   public:
      virtual const Trentino::XML::Schema::QName& xsdType() const;

      //element accessors  
      ExtensionsPtr extensionsElement() const;
      void setExtensions(const ExtensionsPtr& extensions);
      ImplementationPtr implementationElement() const;
      void setImplementation(const ImplementationPtr& implementation);
      std::vector<PolicySetAttachmentPtr>& policySetAttachmentElements();
      std::vector<PropertyValuePtr>& propertyElements();
      std::vector<ComponentReferencePtr>& referenceElements();
      std::vector<RequiresPtr>& requiresElements();
      std::vector<ComponentServicePtr>& serviceElements();

      //attribute accessors
      bool isAutowire() const;
      void setAutowire(bool isAutowire);
      const Trentino::XML::Schema::NCName& name() const;
      void setName(const Trentino::XML::Schema::NCName& name);
      std::vector<QNamePtr>& policySets();
      //data
   protected:
      //elements
      ExtensionsPtr mExtensionsElement;
      ImplementationPtr mImplementationElement;
      std::vector<PolicySetAttachmentPtr> mPolicySetAttachmentElements;
      std::vector<PropertyValuePtr> mPropertyElements;
      std::vector<ComponentReferencePtr> mReferenceElements;
      std::vector<RequiresPtr> mRequiresElements;
      std::vector<ComponentServicePtr> mServiceElements;
 
      //attributes
      bool mIsAutowire;
      Trentino::XML::Schema::NCName mName;   
      std::vector<QNamePtr> mPolicySets;
   }; //class  Component

   #include "TrentinoSCAModelComponent.inl"   

} //namespace Model
} //namespace SCA
} //namespace Trentino

#endif //TrentinoSCAModelComponentH
