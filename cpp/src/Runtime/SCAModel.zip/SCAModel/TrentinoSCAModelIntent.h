// **********************************************************************************
// Trentino - A C++ based lightweight, non-invasive SCA runtime.
// Copyright 2011 by Siemens AG. All rights reserved.
// http://trentino.sourceforge.net/
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// **********************************************************************************

#ifndef TrentinoSCAModelIntentH
#define TrentinoSCAModelIntentH
//standard
#include <vector>

//specific
#include "TrentinoSCAModel.h"

namespace Trentino{
namespace SCA{
namespace Model
{
   class Intent
   {
      //construction
   public:
      Intent();
      virtual ~Intent() {}; 
   private:
      Intent(const Intent&);
      void operator=(const Intent&);

      //services
   public:
      virtual const Trentino::XML::Schema::QName& xsdType() const;

      //element accessors  
      const std::string& descriptionElement() const;
      void setDescription(const std::string& description);
      std::vector<IntentQualifierPtr>& qualifierElements();

      //attribute accessors
      std::vector<QNamePtr>& constrains();
      std::vector<QNamePtr>& excludes();
      InteractionOrImplementationPtr intentType() const;
      void setIntentType(const InteractionOrImplementationPtr& intentType);
      bool isMutuallyExclusive() const;
      void setMutuallyExclusive(bool isMutuallyExclusive);
      const Trentino::XML::Schema::NCName& name() const;
      void setName(const Trentino::XML::Schema::NCName& name);
      std::vector<QNamePtr>& requires();
      //data
   protected:
      //elements
      std::string mDescriptionElement;
      std::vector<IntentQualifierPtr> mQualifierElements;
 
      //attributes
      std::vector<QNamePtr> mConstrains;
      std::vector<QNamePtr> mExcludes;
      InteractionOrImplementationPtr mIntentType;
      bool mIsMutuallyExclusive;
      Trentino::XML::Schema::NCName mName;   
      std::vector<QNamePtr> mRequires;
   }; //class  Intent

   #include "TrentinoSCAModelIntent.inl"   

} //namespace Model
} //namespace SCA
} //namespace Trentino

#endif //TrentinoSCAModelIntentH
