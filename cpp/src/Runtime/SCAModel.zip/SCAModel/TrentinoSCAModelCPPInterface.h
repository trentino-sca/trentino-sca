// **********************************************************************************
// Trentino - A C++ based lightweight, non-invasive SCA runtime.
// Copyright 2011 by Siemens AG. All rights reserved.
// http://trentino.sourceforge.net/
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// **********************************************************************************

#ifndef TrentinoSCAModelCPPInterfaceH
#define TrentinoSCAModelCPPInterfaceH
//baseclass
#include "TrentinoSCAModelInterface.h"
//standard
#include <vector>

//specific
#include "TrentinoSCAModel.h"

namespace Trentino{
namespace SCA{
namespace Model
{
   class SCAMODEL_IMPORT_EXPORT CPPInterface : public Interface
   {
      //construction
   public:
      CPPInterface();
      virtual ~CPPInterface() {}; 
   private:
      CPPInterface(const CPPInterface&);
      void operator=(const CPPInterface&);

      //services
   public:
      virtual const Trentino::XML::Schema::QName& xsdType() const;

      //element accessors  
      std::vector<CPPFunctionPtr>& callbackFunctionElements();
      std::vector<CPPFunctionPtr>& functionElements();

      //attribute accessors
      const Trentino::XML::Schema::Name& callbackClass() const;
      void setCallbackClass(const Trentino::XML::Schema::Name& callbackClass);
      const std::string& callbackHeader() const;
      void setCallbackHeader(const std::string& callbackHeader);
      const Trentino::XML::Schema::Name& clazz() const;
      void setClazz(const Trentino::XML::Schema::Name& clazz);
      const std::string& header() const;
      void setHeader(const std::string& header);
      //data
   protected:
      //elements
      std::vector<CPPFunctionPtr> mCallbackFunctionElements;
      std::vector<CPPFunctionPtr> mFunctionElements;
 
      //attributes
      Trentino::XML::Schema::Name mCallbackClass;   
      std::string mCallbackHeader;
      Trentino::XML::Schema::Name mClazz;   
      std::string mHeader;
   }; //class  CPPInterface

   #include "TrentinoSCAModelCPPInterface.inl"   

} //namespace Model
} //namespace SCA
} //namespace Trentino

#endif //TrentinoSCAModelCPPInterfaceH
