// **********************************************************************************
// Trentino - A C++ based lightweight, non-invasive SCA runtime.
// Copyright 2011 by Siemens AG. All rights reserved.
// http://trentino.sourceforge.net/
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// **********************************************************************************

#ifndef TrentinoSCAModelWireH
#define TrentinoSCAModelWireH
//baseclass
#include "TrentinoSCAModelCommonExtensionBase.h"

//specific
#include "TrentinoSCAModel.h"

namespace Trentino{
namespace SCA{
namespace Model
{
   class Wire : public CommonExtensionBase
   {
      //construction
   public:
      Wire();
      virtual ~Wire() {}; 
   private:
      Wire(const Wire&);
      void operator=(const Wire&);

      //services
   public:
      virtual const Trentino::XML::Schema::QName& xsdType() const;


      //attribute accessors
      bool isReplace() const;
      void setReplace(bool isReplace);
      const Trentino::XML::Schema::AnyURI& source() const;
      void setSource(const Trentino::XML::Schema::AnyURI& source);
      const Trentino::XML::Schema::AnyURI& target() const;
      void setTarget(const Trentino::XML::Schema::AnyURI& target);
      //data
   protected:
 
      //attributes
      bool mIsReplace;
      Trentino::XML::Schema::AnyURI mSource;   
      Trentino::XML::Schema::AnyURI mTarget;   
   }; //class  Wire

   #include "TrentinoSCAModelWire.inl"   

} //namespace Model
} //namespace SCA
} //namespace Trentino

#endif //TrentinoSCAModelWireH
