// **********************************************************************************
// Trentino - A C++ based lightweight, non-invasive SCA runtime.
// Copyright 2011 by Siemens AG. All rights reserved.
// http://trentino.sourceforge.net/
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// **********************************************************************************

#ifndef TrentinoSCAModelSCAPropertyBaseH
#define TrentinoSCAModelSCAPropertyBaseH

//specific
#include "TrentinoSCAModel.h"

namespace Trentino{
namespace SCA{
namespace Model
{
   class SCAPropertyBase
   {
      //construction
   public:
      SCAPropertyBase();
      virtual ~SCAPropertyBase() {}; 
   private:
      SCAPropertyBase(const SCAPropertyBase&);
      void operator=(const SCAPropertyBase&);

      //services
   public:
      virtual const Trentino::XML::Schema::QName& xsdType() const;


      //attribute accessors
      QNamePtr element() const;
      void setElement(const QNamePtr& element);
      bool isMany() const;
      void setMany(bool isMany);
      const Trentino::XML::Schema::NCName& name() const;
      void setName(const Trentino::XML::Schema::NCName& name);
      QNamePtr type() const;
      void setType(const QNamePtr& type);
      const std::string& value() const;
      void setValue(const std::string& value);
      //data
   protected:
 
      //attributes
      QNamePtr mElement;
      bool mIsMany;
      Trentino::XML::Schema::NCName mName;   
      QNamePtr mType;
      std::string mValue;
   }; //class  SCAPropertyBase

   #include "TrentinoSCAModelSCAPropertyBase.inl"   

} //namespace Model
} //namespace SCA
} //namespace Trentino

#endif //TrentinoSCAModelSCAPropertyBaseH
