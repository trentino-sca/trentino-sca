// **********************************************************************************
// Trentino - A C++ based lightweight, non-invasive SCA runtime.
// Copyright 2011 by Siemens AG. All rights reserved.
// http://trentino.sourceforge.net/
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// **********************************************************************************

#ifndef TrentinoSCAModelCPPImplementationH
#define TrentinoSCAModelCPPImplementationH
//baseclass
#include "TrentinoSCAModelImplementation.h"
//standard
#include <vector>

//specific
#include "TrentinoSCAModel.h"

namespace Trentino{
namespace SCA{
namespace Model
{
   class SCAMODEL_IMPORT_EXPORT CPPImplementation : public Implementation
   {
      //construction
   public:
      CPPImplementation();
      virtual ~CPPImplementation() {}; 
   private:
      CPPImplementation(const CPPImplementation&);
      void operator=(const CPPImplementation&);

      //services
   public:
      virtual const Trentino::XML::Schema::QName& xsdType() const;

      //element accessors  
      std::vector<CPPImplementationFunctionPtr>& functionElements();

      //attribute accessors
      bool isAllowsPassByReference() const;
      void setAllowsPassByReference(bool isAllowsPassByReference);
      const Trentino::XML::Schema::Name& clazz() const;
      void setClazz(const Trentino::XML::Schema::Name& clazz);
      const std::string& componentType() const;
      void setComponentType(const std::string& componentType);
      bool isEagerInit() const;
      void setEagerInit(bool isEagerInit);
      const Trentino::XML::Schema::NCName& header() const;
      void setHeader(const Trentino::XML::Schema::NCName& header);
      const Trentino::XML::Schema::NCName& library() const;
      void setLibrary(const Trentino::XML::Schema::NCName& library);
      const std::string& path() const;
      void setPath(const std::string& path);
      CPPImplementationScopePtr scope() const;
      void setScope(const CPPImplementationScopePtr& scope);
      //data
   protected:
      //elements
      std::vector<CPPImplementationFunctionPtr> mFunctionElements;
 
      //attributes
      bool mIsAllowsPassByReference;
      Trentino::XML::Schema::Name mClazz;   
      std::string mComponentType;
      bool mIsEagerInit;
      Trentino::XML::Schema::NCName mHeader;   
      Trentino::XML::Schema::NCName mLibrary;   
      std::string mPath;
      CPPImplementationScopePtr mScope;
   }; //class  CPPImplementation

   #include "TrentinoSCAModelCPPImplementation.inl"   

} //namespace Model
} //namespace SCA
} //namespace Trentino

#endif //TrentinoSCAModelCPPImplementationH
